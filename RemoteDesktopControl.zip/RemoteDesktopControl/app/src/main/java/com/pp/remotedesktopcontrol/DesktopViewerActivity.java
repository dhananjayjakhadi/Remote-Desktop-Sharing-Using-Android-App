package com.pp.remotedesktopcontrol;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pp.remotedesktopcontrol.utilities.Config;
import com.pp.remotedesktopcontrol.utilities.ConnectionDetector;
import com.pp.remotedesktopcontrol.utilities.JSONParser;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class DesktopViewerActivity extends Activity implements Runnable, NavigationView.OnNavigationItemSelectedListener, GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener, View.OnTouchListener, View.OnClickListener {
    AsyncTask<String,Void,String> setOperation_Async;
    JSONParser jsonParser=new JSONParser();
    ConnectionDetector cd;

    GestureDetector gestureDetector;
    ImageView ivDesktop;
    LinearLayout llKeyboard,lls1,llS1,lls2,llS2,lls3,llS3,lls4,llS4;
    TextView tvStartButton,tvMinimise,tvRestore,tvExit,tvKeyboard,tvRun,tvHelp,tvLogout,tvSleep,tvRestart,tvShutdown;
    TextView tvF1,tvF2,tvF3,tvF4,tvF5,tvF6,tvF7,tvF8,tvF9,tvF10,tvF11,tvF12;
    TextView tv1,tv2,tv3,tv4,tv5,tv6,tv7,tv8,tv9,tv0;
    TextView tvq,tvw,tve,tvr,tvt,tvy,tvu,tvi,tvo,tvp, tvQ,tvW,tvE,tvR,tvT,tvY,tvU,tvI,tvO,tvP;
    TextView tva,tvs,tvd,tvf,tvg,tvh,tvj,tvk,tvl, tvA,tvS,tvD,tvF,tvG,tvH,tvJ,tvK,tvL;
    TextView tvz,tvx,tvc,tvv,tvb,tvn,tvm, tvZ,tvX,tvC,tvV,tvB,tvN,tvM;
    TextView tvTilt,tvTilt1,tvExl,tvAt,tvHash,tvDollor,tvPercent,tvRaise,tvAmp,tvAsterisk,tvOpBr,tvClBr,tvDash,tvUnderScore,tvPlus,tvEqualTo;
    TextView tvOpSqBr,tvClSqBr,tvOpCuBr,tvClCuBr,tvLine,tvSlash,tvColon,tvSemiColon,tvSingleQuote,tvDoubleQuote,tvLT,tvGT,tvComma,tvFullStop,tvQuestionMar,tvBackSlash;
    TextView tvEsc,tvBackspace,tvEnter,tvSpace,tvTab,tvLShift,tvRShift,tvLCtrl,tvRCtrl,tvLAlt,tvRAlt,tvCapsLock;
    boolean running=false,caps_lock;

    Matrix matrix = new Matrix();
    float screenWidth=0,imageWidth=200;//ivConversationMedia.getWidth();
    float screenHeight=0,imageHeight=200;//ivConversationMedia.getHeight();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_desktop_viewer);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
//        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
//                this, drawer, toolbar, R.string.navigation_drawer_close,R.string.navigation_drawer_open);
//        drawer.setDrawerListener(toggle);
//        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View navigationHeader=navigationView.getHeaderView(0);
        tvMinimise=(TextView)navigationHeader.findViewById(R.id.tvNavMinimize);
        tvRestore=(TextView)navigationHeader.findViewById(R.id.tvNavMaximizeRestore);
        tvExit=(TextView)navigationHeader.findViewById(R.id.tvNavExit);
        tvStartButton=(TextView)navigationHeader.findViewById(R.id.tvNavStart);
        tvKeyboard=(TextView)navigationHeader.findViewById(R.id.tvNavKeyboard);
        tvRun=(TextView)navigationHeader.findViewById(R.id.tvNavRun);
        tvHelp=(TextView)navigationHeader.findViewById(R.id.tvNavHelp);
        tvLogout=(TextView)navigationHeader.findViewById(R.id.tvNavLogout);
        tvSleep=(TextView)navigationHeader.findViewById(R.id.tvNavSleep);
        tvRestart=(TextView)navigationHeader.findViewById(R.id.tvNavRestart);
        tvShutdown=(TextView)navigationHeader.findViewById(R.id.tvNavShutdown);
        ivDesktop=(ImageView)findViewById(R.id.ivDesktop);

        ivDesktop.setOnTouchListener(this);

        llKeyboard=(LinearLayout)findViewById(R.id.llKeyBoard);
        lls1=(LinearLayout)findViewById(R.id.lls1);
        llS1=(LinearLayout)findViewById(R.id.llS1);
        lls2=(LinearLayout)findViewById(R.id.lls2);
        llS2=(LinearLayout)findViewById(R.id.llS2);
        lls3=(LinearLayout)findViewById(R.id.lls3);
        llS3=(LinearLayout)findViewById(R.id.llS3);
        lls4=(LinearLayout)findViewById(R.id.lls4);
        llS4=(LinearLayout)findViewById(R.id.llS4);

        tvF1=(TextView)findViewById(R.id.tvF1);
        tvF1.setOnClickListener(this);
        tvF2=(TextView)findViewById(R.id.tvF2);
        tvF2.setOnClickListener(this);
        tvF3=(TextView)findViewById(R.id.tvF3);
        tvF3.setOnClickListener(this);
        tvF4=(TextView)findViewById(R.id.tvF4);
        tvF4.setOnClickListener(this);
        tvF5=(TextView)findViewById(R.id.tvF5);
        tvF5.setOnClickListener(this);
        tvF6=(TextView)findViewById(R.id.tvF6);
        tvF6.setOnClickListener(this);
        tvF7=(TextView)findViewById(R.id.tvF7);
        tvF7.setOnClickListener(this);
        tvF8=(TextView)findViewById(R.id.tvF8);
        tvF8.setOnClickListener(this);
        tvF9=(TextView)findViewById(R.id.tvF9);
        tvF9.setOnClickListener(this);
        tvF10=(TextView)findViewById(R.id.tvF10);
        tvF10.setOnClickListener(this);
        tvF11=(TextView)findViewById(R.id.tvF11);
        tvF11.setOnClickListener(this);
        tvF12=(TextView)findViewById(R.id.tvF12);
        tvF12.setOnClickListener(this);
        tv1=(TextView)findViewById(R.id.tv1);
        tv1.setOnClickListener(this);
        tv2=(TextView)findViewById(R.id.tv2);
        tv2.setOnClickListener(this);
        tv3=(TextView)findViewById(R.id.tv3);
        tv3.setOnClickListener(this);
        tv4=(TextView)findViewById(R.id.tv4);
        tv4.setOnClickListener(this);
        tv5=(TextView)findViewById(R.id.tv5);
        tv5.setOnClickListener(this);
        tv6=(TextView)findViewById(R.id.tv6);
        tv6.setOnClickListener(this);
        tv7=(TextView)findViewById(R.id.tv7);
        tv7.setOnClickListener(this);
        tv8=(TextView)findViewById(R.id.tv8);
        tv8.setOnClickListener(this);
        tv9=(TextView)findViewById(R.id.tv9);
        tv9.setOnClickListener(this);
        tv0=(TextView)findViewById(R.id.tv0);
        tv0.setOnClickListener(this);

        tvq=(TextView)findViewById(R.id.tvq);
        tvq.setOnClickListener(this);
        tvw=(TextView)findViewById(R.id.tvw);
        tvw.setOnClickListener(this);
        tve=(TextView)findViewById(R.id.tve);
        tve.setOnClickListener(this);
        tvr=(TextView)findViewById(R.id.tvr);
        tvr.setOnClickListener(this);
        tvt=(TextView)findViewById(R.id.tvt);
        tvt.setOnClickListener(this);
        tvy=(TextView)findViewById(R.id.tvy);
        tvy.setOnClickListener(this);
        tvu=(TextView)findViewById(R.id.tvu);
        tvu.setOnClickListener(this);
        tvi=(TextView)findViewById(R.id.tvi);
        tvi.setOnClickListener(this);
        tvo=(TextView)findViewById(R.id.tvo);
        tvo.setOnClickListener(this);
        tvp=(TextView)findViewById(R.id.tvp);
        tvp.setOnClickListener(this);
        tvQ=(TextView)findViewById(R.id.tvQ);
        tvQ.setOnClickListener(this);
        tvW=(TextView)findViewById(R.id.tvW);
        tvW.setOnClickListener(this);
        tvE=(TextView)findViewById(R.id.tvE);
        tvE.setOnClickListener(this);
        tvR=(TextView)findViewById(R.id.tvR);
        tvR.setOnClickListener(this);
        tvT=(TextView)findViewById(R.id.tvT);
        tvT.setOnClickListener(this);
        tvY=(TextView)findViewById(R.id.tvY);
        tvY.setOnClickListener(this);
        tvU=(TextView)findViewById(R.id.tvU);
        tvU.setOnClickListener(this);
        tvI=(TextView)findViewById(R.id.tvI);
        tvI.setOnClickListener(this);
        tvO=(TextView)findViewById(R.id.tvO);
        tvO.setOnClickListener(this);
        tvP=(TextView)findViewById(R.id.tvP);
        tvP.setOnClickListener(this);
        tva=(TextView)findViewById(R.id.tva);
        tva.setOnClickListener(this);
        tvs=(TextView)findViewById(R.id.tvs);
        tvs.setOnClickListener(this);
        tvd=(TextView)findViewById(R.id.tvd);
        tvd.setOnClickListener(this);
        tvf=(TextView)findViewById(R.id.tvf);
        tvf.setOnClickListener(this);
        tvg=(TextView)findViewById(R.id.tvg);
        tvg.setOnClickListener(this);
        tvh=(TextView)findViewById(R.id.tvh);
        tvh.setOnClickListener(this);
        tvj=(TextView)findViewById(R.id.tvj);
        tvj.setOnClickListener(this);
        tvk=(TextView)findViewById(R.id.tvk);
        tvk.setOnClickListener(this);
        tvl=(TextView)findViewById(R.id.tvl);
        tvl.setOnClickListener(this);
        tvA=(TextView)findViewById(R.id.tvA);
        tvA.setOnClickListener(this);
        tvS=(TextView)findViewById(R.id.tvS);
        tvS.setOnClickListener(this);
        tvD=(TextView)findViewById(R.id.tvD);
        tvD.setOnClickListener(this);
        tvF=(TextView)findViewById(R.id.tvF);
        tvF.setOnClickListener(this);
        tvG=(TextView)findViewById(R.id.tvG);
        tvG.setOnClickListener(this);
        tvH=(TextView)findViewById(R.id.tvH);
        tvH.setOnClickListener(this);
        tvJ=(TextView)findViewById(R.id.tvJ);
        tvJ.setOnClickListener(this);
        tvK=(TextView)findViewById(R.id.tvK);
        tvK.setOnClickListener(this);
        tvL=(TextView)findViewById(R.id.tvL);
        tvL.setOnClickListener(this);
        tvz=(TextView)findViewById(R.id.tvz);
        tvz.setOnClickListener(this);
        tvx=(TextView)findViewById(R.id.tvx);
        tvx.setOnClickListener(this);
        tvc=(TextView)findViewById(R.id.tvc);
        tvc.setOnClickListener(this);
        tvv=(TextView)findViewById(R.id.tvv);
        tvv.setOnClickListener(this);
        tvb=(TextView)findViewById(R.id.tvb);
        tvb.setOnClickListener(this);
        tvn=(TextView)findViewById(R.id.tvn);
        tvn.setOnClickListener(this);
        tvm=(TextView)findViewById(R.id.tvm);
        tvm.setOnClickListener(this);
        tvZ=(TextView)findViewById(R.id.tvZ);
        tvZ.setOnClickListener(this);
        tvX=(TextView)findViewById(R.id.tvX);
        tvX.setOnClickListener(this);
        tvC=(TextView)findViewById(R.id.tvC);
        tvC.setOnClickListener(this);
        tvV=(TextView)findViewById(R.id.tvV);
        tvV.setOnClickListener(this);
        tvB=(TextView)findViewById(R.id.tvB);
        tvB.setOnClickListener(this);
        tvN=(TextView)findViewById(R.id.tvN);
        tvN.setOnClickListener(this);
        tvM=(TextView)findViewById(R.id.tvM);
        tvM.setOnClickListener(this);
        tvTilt=(TextView)findViewById(R.id.tvTilt);
        tvTilt.setOnClickListener(this);
        tvTilt1=(TextView)findViewById(R.id.tvTilt1);
        tvTilt1.setOnClickListener(this);
        tvExl=(TextView)findViewById(R.id.tvExclametory);
        tvExl.setOnClickListener(this);
        tvAt=(TextView)findViewById(R.id.tvAtTheRate);
        tvAt.setOnClickListener(this);
        tvHash=(TextView)findViewById(R.id.tvHash);
        tvHash.setOnClickListener(this);
        tvDollor=(TextView)findViewById(R.id.tvDollor);
        tvDollor.setOnClickListener(this);
        tvPercent=(TextView)findViewById(R.id.tvPercent);
        tvPercent.setOnClickListener(this);
        tvRaise=(TextView)findViewById(R.id.tvRaisedTo);
        tvRaise.setOnClickListener(this);
        tvAmp=(TextView)findViewById(R.id.tvAmpercent);
        tvAmp.setOnClickListener(this);
        tvAsterisk=(TextView)findViewById(R.id.tvAsterisk);
        tvAsterisk.setOnClickListener(this);
        tvOpBr=(TextView)findViewById(R.id.tvOpeningBraces);
        tvOpBr.setOnClickListener(this);
        tvClBr=(TextView)findViewById(R.id.tvClosingBraces);
        tvClBr.setOnClickListener(this);
        tvDash=(TextView)findViewById(R.id.tvDash);
        tvDash.setOnClickListener(this);
        tvUnderScore=(TextView)findViewById(R.id.tvUnderScore);
        tvUnderScore.setOnClickListener(this);
        tvPlus=(TextView)findViewById(R.id.tvPlus);
        tvPlus.setOnClickListener(this);
        tvEqualTo=(TextView)findViewById(R.id.tvEqualTo);
        tvEqualTo.setOnClickListener(this);
        tvOpSqBr=(TextView)findViewById(R.id.tvOpeningSquareBraces);
        tvOpSqBr.setOnClickListener(this);
        tvClSqBr=(TextView)findViewById(R.id.tvClosingSquareBraces);
        tvClSqBr.setOnClickListener(this);
        tvOpCuBr=(TextView)findViewById(R.id.tvOpeningCurlyBraces);
        tvOpCuBr.setOnClickListener(this);
        tvClCuBr=(TextView)findViewById(R.id.tvClosingCurlyBraces);
        tvClCuBr.setOnClickListener(this);
        tvLine=(TextView)findViewById(R.id.tvLine);
        tvLine.setOnClickListener(this);
        tvSlash=(TextView)findViewById(R.id.tvSlash);
        tvSlash.setOnClickListener(this);
        tvColon=(TextView)findViewById(R.id.tvColon);
        tvColon.setOnClickListener(this);
        tvSemiColon=(TextView)findViewById(R.id.tvSemiColon);
        tvSemiColon.setOnClickListener(this);
        tvSingleQuote=(TextView)findViewById(R.id.tvSingleQuote);
        tvSingleQuote.setOnClickListener(this);
        tvDoubleQuote=(TextView)findViewById(R.id.tvDoubleQuote);
        tvDoubleQuote.setOnClickListener(this);
        tvLT=(TextView)findViewById(R.id.tvLessThan);
        tvLT.setOnClickListener(this);
        tvGT=(TextView)findViewById(R.id.tvGreaterThan);
        tvGT.setOnClickListener(this);
        tvComma=(TextView)findViewById(R.id.tvComma);
        tvComma.setOnClickListener(this);
        tvFullStop=(TextView)findViewById(R.id.tvFullStop);
        tvFullStop.setOnClickListener(this);
        tvQuestionMar=(TextView)findViewById(R.id.tvQuestionMark);
        tvQuestionMar.setOnClickListener(this);
        tvBackSlash=(TextView)findViewById(R.id.tvBackSlash);
        tvBackSlash.setOnClickListener(this);
        tvEsc=(TextView)findViewById(R.id.tvEsc);
        tvEsc.setOnClickListener(this);
        tvBackspace=(TextView)findViewById(R.id.tvBackspace);
        tvBackspace.setOnClickListener(this);
        tvEnter=(TextView)findViewById(R.id.tvEnter);
        tvEnter.setOnClickListener(this);
        tvSpace=(TextView)findViewById(R.id.tvSpace);
        tvSpace.setOnClickListener(this);
        tvTab=(TextView)findViewById(R.id.tvTab);
        tvTab.setOnClickListener(this);
        tvLShift=(TextView)findViewById(R.id.tvLeftShift);
        tvLShift.setOnClickListener(this);
        tvRShift=(TextView)findViewById(R.id.tvRightShift);
        tvRShift.setOnClickListener(this);
        tvLCtrl=(TextView)findViewById(R.id.tvLeftCtrl);
        tvLCtrl.setOnClickListener(this);
        tvRCtrl=(TextView)findViewById(R.id.tvRightCtrl);
        tvRCtrl.setOnClickListener(this);
        tvLAlt=(TextView)findViewById(R.id.tvLeftAlt);
        tvLAlt.setOnClickListener(this);
        tvRAlt=(TextView)findViewById(R.id.tvRightAlt);
        tvRAlt.setOnClickListener(this);
        tvCapsLock=(TextView)findViewById(R.id.tvCapsLock);
        tvCapsLock.setOnClickListener(this);

        tvMinimise.setOnClickListener(this);
        tvRestore.setOnClickListener(this);
        tvExit.setOnClickListener(this);
        tvStartButton.setOnClickListener(this);
        tvKeyboard.setOnClickListener(this);
        tvRun.setOnClickListener(this);
        tvHelp.setOnClickListener(this);
        tvLogout.setOnClickListener(this);
        tvSleep.setOnClickListener(this);
        tvRestart.setOnClickListener(this);
        tvShutdown.setOnClickListener(this);

        gestureDetector=new GestureDetector(this);
        gestureDetector.setOnDoubleTapListener(this);
        cd=new ConnectionDetector(this);

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;

        String url= Config.get_url+
                "action=set_operation"+
                "&operation=0";
        setOperation_Async=new SetOperation_Async();
        setOperation_Async.execute(url);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onResume() {
        running=true;
        Thread t=new Thread(this);
        t.start();
        super.onResume();
    }

    @Override
    protected void onRestart() {
        running=true;
        Thread t=new Thread(this);
        t.start();
        super.onRestart();
    }

    @Override
    protected void onPause() {
        running=false;
        super.onPause();
    }

    @Override
    protected void onStop() {
        running=false;
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        running=false;
        super.onDestroy();
    }

    @Override
    public void run() {
        while(running){
            final Bitmap bitmap=getBitmap(Config.media_url+"0.jpg");
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ivDesktop.setImageBitmap(bitmap);
//                    Log.e("l", "Image Width : " + imageWidth + " > " + imageHeight);
//                    Log.e("l", "screen Width : " + screenWidth + " > " + screenHeight);

                    RectF drawableRect = new RectF(0, 0, imageWidth, imageHeight);
                    RectF viewRect = new RectF(0, 0, screenWidth, screenHeight);

                    matrix.setRectToRect(drawableRect, viewRect, Matrix.ScaleToFit.CENTER);
                    ivDesktop.setImageMatrix(matrix);
                }
            });
        }
    }

    public Bitmap getBitmap(String url) {
        // Download Images from the Internet
        try {
            Bitmap bitmap = null;
            URL imageUrl = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) imageUrl.openConnection();
            //conn.setConnectTimeout(30000);
            //conn.setReadTimeout(30000);
            conn.setInstanceFollowRedirects(true);
            InputStream is = conn.getInputStream();
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = 1;
            bitmap = BitmapFactory.decodeStream(is, null, o2);
            imageWidth=bitmap.getWidth();
            imageHeight=bitmap.getHeight();
            //Log.e("screen size","width:" + imageWidth + " height:" + imageHeight);
            conn.disconnect();
            is.close();
            return bitmap;
        } catch (Throwable ex) {
            ex.printStackTrace();
            if (ex instanceof OutOfMemoryError)
            return null;
        }
        return null;
    }

    Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

        }
    };

    @Override
    public boolean onDown(MotionEvent e) {
        return true;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        String url= Config.get_url+
                "action=set_operation"+
                "&operation=2"+
                "&operation_parameters="+getConvertDesktopX(e2.getX())+","+getConvertDesktopY(e2.getY());
        setOperation_Async=new SetOperation_Async();
        setOperation_Async.execute(url);
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {
        String url= Config.get_url+
                "action=set_operation"+
                "&operation=5";
        setOperation_Async=new SetOperation_Async();
        setOperation_Async.execute(url);
    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return false;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        String url= Config.get_url+
                "action=set_operation"+
                "&operation=3";
        setOperation_Async=new SetOperation_Async();
        setOperation_Async.execute(url);
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        String url= Config.get_url+
                "action=set_operation"+
                "&operation=4";
        setOperation_Async=new SetOperation_Async();
        setOperation_Async.execute(url);
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        return gestureDetector.onTouchEvent(event);
    }

    public int getConvertDesktopX(float x){
        return (int) (x*imageWidth/screenWidth);
    }

    public int getConvertDesktopY(float y){
        return (int) (y*imageWidth/screenWidth);
    }

    @Override
    public void onClick(View v) {
        if (v == tvMinimise) {
            String url = Config.get_url +
                    "action=set_operation" +
                    "&operation=9";
            setOperation_Async = new SetOperation_Async();
            setOperation_Async.execute(url);
        } else if (v == tvRestore) {
            String url = Config.get_url +
                    "action=set_operation" +
                    "&operation=10";
            setOperation_Async = new SetOperation_Async();
            setOperation_Async.execute(url);
        } else if (v == tvExit) {
            String url = Config.get_url +
                    "action=set_operation" +
                    "&operation=11";
            setOperation_Async = new SetOperation_Async();
            setOperation_Async.execute(url);
        } else if (v == tvStartButton) {
            String url = Config.get_url +
                    "action=set_operation" +
                    "&operation=6";
            setOperation_Async = new SetOperation_Async();
            setOperation_Async.execute(url);
        } else if (v == tvKeyboard) {
            if(llKeyboard.getVisibility()==View.GONE) {
                llKeyboard.setVisibility(View.VISIBLE);
            }else{
                llKeyboard.setVisibility(View.GONE);
            }
        } else if (v == tvRun) {
            String url = Config.get_url +
                    "action=set_operation" +
                    "&operation=12";
            setOperation_Async = new SetOperation_Async();
            setOperation_Async.execute(url);
        } else if (v == tvHelp) {
            String url = Config.get_url +
                    "action=set_operation" +
                    "&operation=7";
            setOperation_Async = new SetOperation_Async();
            setOperation_Async.execute(url);
        } else if (v == tvLogout) {
            String url = Config.get_url +
                    "action=set_operation" +
                    "&operation=8";
            setOperation_Async = new SetOperation_Async();
            setOperation_Async.execute(url);
        } else if (v == tvSleep) {
            String url = Config.get_url +
                    "action=set_operation" +
                    "&operation=15";
            setOperation_Async = new SetOperation_Async();
            setOperation_Async.execute(url);
        } else if (v == tvRestart) {
            String url = Config.get_url +
                    "action=set_operation" +
                    "&operation=16";
            setOperation_Async = new SetOperation_Async();
            setOperation_Async.execute(url);
        } else if (v == tvShutdown) {
            String url = Config.get_url +
                    "action=set_operation" +
                    "&operation=17";
            setOperation_Async = new SetOperation_Async();
            setOperation_Async.execute(url);
        } else if (v == tvF1) {
            setOperation("14", tvF1.getText().toString());
        } else if (v == tvF2) {
            setOperation("14", tvF2.getText().toString());
        } else if (v == tvF3) {
            setOperation("14", tvF3.getText().toString());
        } else if (v == tvF4) {
            setOperation("14", tvF4.getText().toString());
        } else if (v == tvF5) {
            setOperation("14", tvF5.getText().toString());
        } else if (v == tvF6) {
            setOperation("14", tvF6.getText().toString());
        } else if (v == tvF7) {
            setOperation("14", tvF7.getText().toString());
        } else if (v == tvF8) {
            setOperation("14", tvF8.getText().toString());
        } else if (v == tvF9) {
            setOperation("14", tvF9.getText().toString());
        } else if (v == tvF10) {
            setOperation("14", tvF10.getText().toString());
        } else if (v == tvF11) {
            setOperation("14", tvF11.getText().toString());
        } else if (v == tvF12) {
            setOperation("14", tvF12.getText().toString());
        } else if (v == tv1) {
            setOperation("13", tv1.getText().toString());
        } else if (v == tv2) {
            setOperation("13", tv2.getText().toString());
        } else if (v == tv3) {
            setOperation("13", tv3.getText().toString());
        } else if (v == tv4) {
            setOperation("13", tv4.getText().toString());
        } else if (v == tv5) {
            setOperation("13", tv5.getText().toString());
        } else if (v == tv6) {
            setOperation("13", tv6.getText().toString());
        } else if (v == tv7) {
            setOperation("13", tv7.getText().toString());
        } else if (v == tv8) {
            setOperation("13", tv8.getText().toString());
        } else if (v == tv9) {
            setOperation("13", tv9.getText().toString());
        } else if (v == tv0) {
            setOperation("13", tv0.getText().toString());
        } else if(v==tvq){
            setOperation("13",tvq.getText().toString());
        } else if(v==tvw){
            setOperation("13",tvw.getText().toString());
        } else if(v==tve){
            setOperation("13",tve.getText().toString());
        } else if(v==tvr){
            setOperation("13",tvr.getText().toString());
        } else if(v==tvt){
            setOperation("13",tvt.getText().toString());
        } else if(v==tvy){
            setOperation("13",tvy.getText().toString());
        } else if(v==tvu){
            setOperation("13",tvu.getText().toString());
        } else if(v==tvi){
            setOperation("13",tvi.getText().toString());
        } else if(v==tvo){
            setOperation("13",tvo.getText().toString());
        } else if(v==tvp){
            setOperation("13",tvp.getText().toString());
        } else if(v==tvQ){
            setOperation("13",tvQ.getText().toString());
        } else if(v==tvW){
            setOperation("13",tvW.getText().toString());
        } else if(v==tvE){
            setOperation("13",tvE.getText().toString());
        } else if(v==tvR){
            setOperation("13",tvR.getText().toString());
        } else if(v==tvT){
            setOperation("13",tvT.getText().toString());
        } else if(v==tvY){
            setOperation("13",tvY.getText().toString());
        } else if(v==tvU){
            setOperation("13",tvU.getText().toString());
        } else if(v==tvI){
            setOperation("13",tvI.getText().toString());
        } else if(v==tvO){
            setOperation("13",tvO.getText().toString());
        } else if(v==tvP){
            setOperation("13",tvP.getText().toString());
        } else if(v==tva){
            setOperation("13",tva.getText().toString());
        } else if(v==tvs){
            setOperation("13",tvs.getText().toString());
        } else if(v==tvd){
            setOperation("13",tvd.getText().toString());
        } else if(v==tvf){
            setOperation("13",tvf.getText().toString());
        } else if(v==tvg){
            setOperation("13",tvg.getText().toString());
        } else if(v==tvh){
            setOperation("13",tvh.getText().toString());
        } else if(v==tvj){
            setOperation("13",tvj.getText().toString());
        } else if(v==tvk){
            setOperation("13",tvk.getText().toString());
        } else if(v==tvl){
            setOperation("13",tvl.getText().toString());
        } else if(v==tvA){
            setOperation("13",tvA.getText().toString());
        } else if(v==tvS){
            setOperation("13",tvS.getText().toString());
        } else if(v==tvD){
            setOperation("13",tvD.getText().toString());
        } else if(v==tvF){
            setOperation("13",tvF.getText().toString());
        } else if(v==tvG){
            setOperation("13",tvG.getText().toString());
        } else if(v==tvH){
            setOperation("13",tvH.getText().toString());
        } else if(v==tvJ){
            setOperation("13",tvJ.getText().toString());
        } else if(v==tvK){
            setOperation("13",tvK.getText().toString());
        } else if(v==tvL){
            setOperation("13",tvL.getText().toString());
        } else if(v==tvz){
            setOperation("13",tvz.getText().toString());
        } else if(v==tvx){
            setOperation("13",tvx.getText().toString());
        } else if(v==tvc){
            setOperation("13",tvc.getText().toString());
        } else if(v==tvv){
            setOperation("13",tvv.getText().toString());
        } else if(v==tvb){
            setOperation("13",tvb.getText().toString());
        } else if(v==tvn){
            setOperation("13",tvn.getText().toString());
        } else if(v==tvm){
            setOperation("13",tvm.getText().toString());
        } else if(v==tvZ){
            setOperation("13",tvZ.getText().toString());
        } else if(v==tvX){
            setOperation("13",tvX.getText().toString());
        } else if(v==tvC){
            setOperation("13",tvC.getText().toString());
        } else if(v==tvV){
            setOperation("13",tvV.getText().toString());
        } else if(v==tvB){
            setOperation("13",tvB.getText().toString());
        } else if(v==tvN){
            setOperation("13",tvN.getText().toString());
        } else if(v==tvM){
            setOperation("13",tvM.getText().toString());
        } else if(v==tvTilt){
            setOperation("13",tvTilt.getText().toString());
        } else if(v==tvTilt1){
            setOperation("13",tvTilt1.getText().toString());
        } else if(v==tvExl){
            setOperation("13",tvExl.getText().toString());
        } else if(v==tvAt){
            setOperation("13",tvAt.getText().toString());
        } else if(v==tvHash){
            setOperation("13",tvHash.getText().toString());
        } else if(v==tvDollor){
            setOperation("13",tvDollor.getText().toString());
        } else if(v==tvPercent){
            setOperation("13",tvPercent.getText().toString());
        } else if(v==tvRaise){
            setOperation("13",tvRaise.getText().toString());
        } else if(v==tvAmp){
            setOperation("13",tvAmp.getText().toString());
        } else if(v==tvAsterisk){
            setOperation("13",tvAsterisk.getText().toString());
        } else if(v==tvOpBr){
            setOperation("13",tvOpBr.getText().toString());
        } else if(v==tvClBr){
            setOperation("13",tvClBr.getText().toString());
        } else if(v==tvDash){
            setOperation("13",tvDash.getText().toString());
        } else if(v==tvUnderScore){
            setOperation("13",tvUnderScore.getText().toString());
        } else if(v==tvPlus){
            setOperation("13",tvPlus.getText().toString());
        } else if(v==tvEqualTo){
            setOperation("13",tvEqualTo.getText().toString());
        } else if(v==tvOpSqBr){
            setOperation("13",tvOpSqBr.getText().toString());
        } else if(v==tvClSqBr){
            setOperation("13",tvClSqBr.getText().toString());
        } else if(v==tvOpCuBr){
            setOperation("13",tvOpCuBr.getText().toString());
        } else if(v==tvClCuBr){
            setOperation("13",tvClCuBr.getText().toString());
        } else if(v==tvLine){
            setOperation("13",tvLine.getText().toString());
        } else if(v==tvSlash){
            setOperation("13",tvSlash.getText().toString());
        } else if(v==tvColon){
            setOperation("13",tvColon.getText().toString());
        } else if(v==tvSemiColon){
            setOperation("13",tvSemiColon.getText().toString());
        } else if(v==tvSingleQuote){
            setOperation("13",tvSingleQuote.getText().toString());
        } else if(v==tvDoubleQuote){
            setOperation("13",tvDoubleQuote.getText().toString());
        } else if(v==tvLT){
            setOperation("13",tvLT.getText().toString());
        } else if(v==tvGT){
            setOperation("13",tvGT.getText().toString());
        } else if(v==tvComma){
            setOperation("13",tvComma.getText().toString());
        } else if(v==tvFullStop){
            setOperation("13",tvFullStop.getText().toString());
        } else if(v==tvQuestionMar){
            setOperation("13",tvQuestionMar.getText().toString());
        } else if(v==tvBackSlash){
            setOperation("13",tvBackSlash.getText().toString());
        } else if(v==tvEsc){
            setOperation("14",tvEsc.getText().toString());
        } else if(v==tvBackspace){
            setOperation("14",""+tvBackspace.getText().toString());
        } else if(v==tvEnter){
            setOperation("13","\n");
        } else if(v==tvSpace){
            setOperation("13"," ");
        } else if(v==tvTab){
            setOperation("14",tvTab.getText().toString());
        } else if(v==tvLShift){
            setOperation("14",tvLShift.getText().toString());
        } else if(v==tvRShift){
            setOperation("14",tvRShift.getText().toString());
        } else if(v==tvLCtrl){
            setOperation("14",tvLCtrl.getText().toString());
        } else if(v==tvRCtrl){
            setOperation("14",tvRCtrl.getText().toString());
        } else if(v==tvLAlt){
            setOperation("14",tvLAlt.getText().toString());
        } else if(v==tvRAlt){
            setOperation("14",tvRAlt.getText().toString());
        } else if(v==tvCapsLock){
            caps_lock=!caps_lock;
            if(caps_lock){
                llS1.setVisibility(View.VISIBLE);
                llS2.setVisibility(View.VISIBLE);
                llS3.setVisibility(View.VISIBLE);
                llS4.setVisibility(View.VISIBLE);
                lls1.setVisibility(View.GONE);
                lls2.setVisibility(View.GONE);
                lls3.setVisibility(View.GONE);
                lls4.setVisibility(View.GONE);
            }else{
                lls1.setVisibility(View.VISIBLE);
                lls2.setVisibility(View.VISIBLE);
                lls3.setVisibility(View.VISIBLE);
                lls4.setVisibility(View.VISIBLE);
                llS1.setVisibility(View.GONE);
                llS2.setVisibility(View.GONE);
                llS3.setVisibility(View.GONE);
                llS4.setVisibility(View.GONE);
            }
        }
    }

    void setOperation(String operation,String operation_parameters){
        try {
            String url=Config.get_url+
                    "action=set_operation"+
                    "&operation="+operation+
                    "&operation_parameters="+URLEncoder.encode(operation_parameters,"utf-8");
            setOperation_Async = new SetOperation_Async();
            setOperation_Async.execute(url);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    class SetOperation_Async extends AsyncTask<String,Void,String>{
        @Override
        protected String doInBackground(String... params) {
            Log.e("url", "" + params[0]);
            return jsonParser.doGetRequest(params[0]);
        }
    }
}
