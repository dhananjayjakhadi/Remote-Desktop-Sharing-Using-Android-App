package com.pp.remotedesktopcontrol.utilities;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by User on 22/09/2017.
 */
public class DBHelper  extends SQLiteOpenHelper{
    public DBHelper(Context context) {
        super(context, "HomeReviseDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table if not exists tbl_login (member_id varchar, member_name varchar, member_mobile varchar, member_email varchar, member_address varchar, member_pincode varchar, member_dob varchar, member_gender varchar, member_password varchar, member_registered_by varchar, member_designation varchar)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists tbl_login");
        onCreate(db);
    }

    public boolean insertLogin(String member_id, String member_name, String member_mobile, String member_email, String member_address, String member_pincode, String member_dob, String member_gender, String member_password, String member_registered_by, String member_designation){
        SQLiteDatabase db=getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("member_id",member_id);
        cv.put("member_name",member_name);
        cv.put("member_mobile",member_mobile);
        cv.put("member_email",member_email);
        cv.put("member_address",member_address);
        cv.put("member_pincode",member_pincode);
        cv.put("member_dob",member_dob);
        cv.put("member_gender",member_gender);
        cv.put("member_password",member_password);
        cv.put("member_registered_by",member_registered_by);
        cv.put("member_designation",member_designation);
        long result=db.insert("tbl_login",null,cv);
        if(result!=-1){
            return true;
        }
        return false;
    }

    public boolean isLoggedIn(){
        SQLiteDatabase db= getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from tbl_login", null);
        if(cursor.moveToFirst()){
            return true;
        }else{
            return false;
        }
    }

    public String getId(){
        SQLiteDatabase db=getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from tbl_login",null);
        if(cursor.moveToFirst()){
            return cursor.getString(cursor.getColumnIndex("member_id"));
        }
        return "";
    }

    public String getCustomerName(){
        SQLiteDatabase db=getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from tbl_login",null);
        if(cursor.moveToFirst()){
            return cursor.getString(cursor.getColumnIndex("member_name"));
        }
        return "";
    }

    public Cursor getProfile(){
        SQLiteDatabase db=getReadableDatabase();
        return db.rawQuery("select * from tbl_login",null);
    }

    public boolean updateProfile(String member_name,String member_email,String member_address, String member_pincode, String member_dob, String member_gender){
        SQLiteDatabase db=getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("member_name",member_name);
        cv.put("member_email",member_email);
        cv.put("member_address",member_address);
        cv.put("member_pincode",member_pincode);
        cv.put("member_dob",member_dob);
        cv.put("member_gender",member_gender);
        long result=db.update("tbl_login", cv, null, null);
        if(result==1){
            return true;
        }
        return false;
    }

    public boolean updateMobile(String member_mobile){
        SQLiteDatabase db=getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("member_mobile",member_mobile);
        long result=db.update("tbl_login",cv,null,null);
        if(result==1){
            return true;
        }
        return false;
    }

    public boolean updatePassword(String member_password){
        SQLiteDatabase db=getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("member_password",member_password);
        long result=db.update("tbl_login",cv,null,null);
        if(result==1){
            return true;
        }
        return false;
    }

    public void logout() {
        SQLiteDatabase db=getWritableDatabase();
        db.delete("tbl_login",null,null);
    }
}