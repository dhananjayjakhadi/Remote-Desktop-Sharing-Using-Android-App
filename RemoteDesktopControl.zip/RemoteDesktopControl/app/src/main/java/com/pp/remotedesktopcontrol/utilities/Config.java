package com.pp.remotedesktopcontrol.utilities;

public class Config {
	public static String get_url="http://192.168.0.5/RemoteDesktopControl/actions.php?";
	public static String post_url="http://192.168.0.5/RemoteDesktopControl/actions.php";
	public static String media_url="http://192.168.0.5/RemoteDesktopControl/";

	public static final String TOPIC_GLOBAL = "global";
	public static final String REGISTRATION_COMPLETE = "registrationComplete";
	public static final String PUSH_NOTIFICATION = "pushNotification";

	// id to handle the notification in the notification tray
	public static int NOTIFICATION_ID = 100;
	public static int NOTIFICATION_ID_BIG_IMAGE = 101;
	public static final String SHARED_PREF="HomeRevise";

	public static boolean validateEmailAddress(String emailAddress) {
		//Pattern regexPattern = Pattern.compile("^[(a-zA-Z-0-9-\\_\\+\\.)]+@[(a-z-A-z)]+\\.[(a-zA-z)]{2,3}$");
//		Pattern regexPattern = Pattern.compile("^[(a-zA-Z-0-9-\\_\\+\\.)]+@[(a-z-A-z)]+\\.^[(a-zA-Z-0-9-\\_\\+\\.)]");
		//Matcher regMatcher   = regexPattern.matcher(emailAddress);


		if(emailAddress.contains("@") && emailAddress.contains(".")) {
			return true;
		} else {
			return false;
		}
	}

	public static void incrementNotificationId(){
		NOTIFICATION_ID++;
		NOTIFICATION_ID_BIG_IMAGE++;
	}
}