<?php
	$con=mysqli_connect("localhost","root","","db_remote_desktop_control");
?>