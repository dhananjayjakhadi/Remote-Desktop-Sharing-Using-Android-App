<?php
	error_reporting(0);
	include 'connections.php';
	$result=array('result'=>"false");
	if(isset($_GET['action'])){
		extract($_GET);
		if($action=="register_desktop"){
			$res=mysqli_query($con,"select * from tbl_remote_desktops where desktop_serial_no='$serial_no'");
			if(mysqli_affected_rows($con)>0){
				$result['result']="true";
			}else{
				mysqli_query($con,"insert into tbl_remote_desktops (desktop_serial_no) values('$serial_no')");
				$result['result']="true";
			}
		}else if($action=="get_operation_id"){
			$res=mysqli_query($con,"select * from tbl_remote_desktops where desktop_serial_no='$serial_no' and operation_status='NEW'");
			if(mysqli_affected_rows($con)>0){
				$row=mysqli_fetch_assoc($res);
				$result['result']="true";
				$result['data']=$row;
			}
		}else if($action=="reset_operation"){
			mysqli_query($con,"update tbl_remote_desktops set operation_status='COMPLETED'");
			if(mysqli_affected_rows($con)>0){
				$result['result']="true";
			}
		}else if($action=="set_operation"){
			mysqli_query($con,"update tbl_remote_desktops set operation='$operation',operation_parameters='$operation_parameters',operation_status='NEW'");
			if(mysqli_affected_rows($con)>0){
				$result['result']="true";
			}
		}
		echo json_encode($result);
	}else if(isset($_POST['action'])){
		extract($_POST);
		if($action=="update_screenshot"){
			if($photo!="" && $base64!=""){
				$data = str_replace('data:image/png;base64,', '', $base64);
				$data = str_replace(' ', '+', $data);
				$data = base64_decode($data);
				$ifp = fopen("".$photo, "wb");
				fwrite($ifp, $data);
			}
			echo "hi";
			/*$query="update tbl_sellers set shop_photo='$shop_photo' where seller_id='$seller_id'";
			mysqli_query($con,$query);
			if(mysqli_affected_rows($con)>0){
				$result['result']="true";
				$result['shop_photo']=$shop_photo;
			}else{
				$result['result']="false";
			}*/
		}
	}
?>